# AK PDF Editor — Android starter project

This is a starter Android Studio project for AK PDF Editor.

## Currently implemented
- Android app shell and home screen
- Open a PDF using Android's document picker
- Render PDF pages with Android `PdfRenderer`
- Navigate previous/next pages

## Planned / not yet implemented
- Add text, drawing, highlights and notes, then save annotations
- Merge/split/reorder/delete PDF pages
- Image-to-PDF
- PDF-to-Word conversion
- Password protection

## Build
1. Install Android Studio (a recent stable version).
2. Open this folder as a project.
3. Allow Gradle sync.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Select Run.

To create an APK in Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

This starter project is not yet the complete feature set; the editing and conversion tools are marked as planned.
