package com.ak.pdfeditor

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var image: ImageView
    private lateinit var status: TextView
    private var renderer: PdfRenderer? = null
    private var descriptor: ParcelFileDescriptor? = null
    private var pageIndex = 0
    private val openPdf = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 247, 250))
            setPadding(18, 18, 18, 12)
        }
        val title = TextView(this).apply {
            text = "AK PDF Editor"
            textSize = 26f
            setTextColor(Color.rgb(13, 71, 161))
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 18)
        }
        root.addView(title)
        val open = button("📂  Open PDF") { choosePdf() }
        root.addView(open)
        status = TextView(this).apply {
            text = "Choose a PDF file to start"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }
        root.addView(status)
        image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.WHITE)
        }
        root.addView(ScrollView(this).apply {
            addView(image)
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("◀ Previous") { showPage(pageIndex - 1) }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button("Next ▶") { showPage(pageIndex + 1) }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
        val tools = button("PDF Tools (coming in next build)") {
            Toast.makeText(this, "Editing, merge and conversion tools are planned for the next build.", Toast.LENGTH_LONG).show()
        }
        root.addView(tools)
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 14f
            setOnClickListener { action() }
        }

    private fun choosePdf() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
        }
        startActivityForResult(intent, openPdf)
    }

    @Deprecated("Deprecated by Android, retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == openPdf && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    closePdf()
                    descriptor = contentResolver.openFileDescriptor(uri, "r")
                    if (descriptor == null) throw Exception("Unable to open file")
                    renderer = PdfRenderer(descriptor!!)
                    pageIndex = 0
                    showPage(0)
                } catch (e: Exception) {
                    status.text = "Could not open PDF: ${e.localizedMessage}"
                }
            }
        }
    }

    private fun showPage(index: Int) {
        val pdf = renderer
        if (pdf == null) {
            Toast.makeText(this, "Please open a PDF first", Toast.LENGTH_SHORT).show()
            return
        }
        if (index !in 0 until pdf.pageCount) {
            Toast.makeText(this, "No more pages", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val page = pdf.openPage(index)
            val width = (page.width * 1.5f).toInt().coerceAtLeast(1)
            val height = (page.height * 1.5f).toInt().coerceAtLeast(1)
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            image.setImageBitmap(bitmap)
            pageIndex = index
            status.text = "Page ${pageIndex + 1} of ${pdf.pageCount}"
        } catch (e: Exception) {
            status.text = "Unable to render page: ${e.localizedMessage}"
        }
    }

    private fun closePdf() {
        try { renderer?.close() } catch (_: Exception) {}
        try { descriptor?.close() } catch (_: Exception) {}
        renderer = null
        descriptor = null
    }

    override fun onDestroy() {
        closePdf()
        super.onDestroy()
    }
}
