package com.ak.pdfeditor

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import android.os.ParcelFileDescriptor
import android.content.ContentValues
import android.provider.MediaStore
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import java.io.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var preview: ImageView
    private lateinit var drawing: InkView
    private lateinit var status: TextView
    private var renderer: PdfRenderer? = null
    private var descriptor: ParcelFileDescriptor? = null
    private var currentUri: Uri? = null
    private var pageIndex = 0
    private var mode = "ink"
    private val pickPdf = 10
    private val pickImage = 11
    private val savePdf = 12
    private val pickMerge = 13
    private var pendingImage: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        buildUi()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245,247,250)); setPadding(12,8,12,8)
        }
        root.addView(TextView(this).apply {
            text="AK PDF Editor"; textSize=25f; gravity=Gravity.CENTER
            setTextColor(Color.rgb(13,71,161)); setPadding(0,8,0,8)
        })
        val top = LinearLayout(this)
        top.addView(button("Open PDF") { choosePdf() }, LinearLayout.LayoutParams(0,-2,1f))
        top.addView(button("Save As") { saveAs() }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(top)
        status = TextView(this).apply { text="Open a PDF to begin"; gravity=Gravity.CENTER; textSize=14f }
        root.addView(status)
        val canvasFrame = android.widget.FrameLayout(this)
        preview = ImageView(this).apply { adjustViewBounds=true; scaleType=ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.WHITE) }
        drawing = InkView(this)
        canvasFrame.addView(preview, android.widget.FrameLayout.LayoutParams(-1,-1))
        canvasFrame.addView(drawing, android.widget.FrameLayout.LayoutParams(-1,-1))
        root.addView(canvasFrame, LinearLayout.LayoutParams(-1,0,1f))
        val nav = LinearLayout(this)
        nav.addView(button("◀") { renderPage(pageIndex-1) }, LinearLayout.LayoutParams(0,-2,1f))
        nav.addView(button("▶") { renderPage(pageIndex+1) }, LinearLayout.LayoutParams(0,-2,1f))
        nav.addView(button("Clear marks") { drawing.clear(); toast("Marks cleared") }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(nav)
        val tools1=LinearLayout(this)
        tools1.addView(button("Draw") { mode="ink"; drawing.tool=InkView.Tool.PEN; toast("Draw mode") }, LinearLayout.LayoutParams(0,-2,1f))
        tools1.addView(button("Highlight") { mode="highlight"; drawing.tool=InkView.Tool.HIGHLIGHT; toast("Highlight mode") }, LinearLayout.LayoutParams(0,-2,1f))
        tools1.addView(button("Add text") { addText() }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(tools1)
        val tools2=LinearLayout(this)
        tools2.addView(button("Images → PDF") { chooseImage() }, LinearLayout.LayoutParams(0,-2,1f))
        tools2.addView(button("Merge PDFs") { mergePdfs() }, LinearLayout.LayoutParams(0,-2,1f))
        tools2.addView(button("Page tools") { pageTools() }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(tools2)
        root.addView(button("PDF → Word / Protect PDF") {
            AlertDialogBuilder("These advanced conversions are not yet implemented in this build.").show()
        })
        setContentView(root)
    }

    private fun button(label:String, action:()->Unit)=Button(this).apply { text=label; textSize=12f; setOnClickListener{action()} }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()

    private fun choosePdf() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="application/pdf"
        },pickPdf)
    }
    private fun chooseImage() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="image/*"
        },pickImage)
    }
    private fun mergePdfs() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="application/pdf"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true)
        },pickMerge)
    }

    @Deprecated("Compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK || data==null) return
        when(requestCode) {
            pickPdf -> data.data?.let { openPdf(it) }
            pickImage -> data.data?.let { uri ->
                try {
                    val bmp=contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) }
                    if(bmp!=null) { pendingImage=bmp; createPdfFromImage(bmp) } else toast("Image could not be read")
                } catch(e:Exception){ toast("Image error: ${e.message}") }
            }
            pickMerge -> {
                val uris= mutableListOf<Uri>()
                data.clipData?.let { clip -> for(i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
                if(uris.isEmpty()) data.data?.let{uris.add(it)}
                if(uris.size>=2) merge(uris) else toast("Select at least two PDF files")
            }
        }
    }

    private fun openPdf(uri:Uri) {
        try {
            closePdf(); currentUri=uri
            descriptor=contentResolver.openFileDescriptor(uri,"r")
            renderer=PdfRenderer(descriptor!!)
            pageIndex=0; drawing.clear(); renderPage(0)
        } catch(e:Exception){ status.text="Open failed: ${e.localizedMessage}" }
    }
    private fun renderPage(index:Int) {
        val r=renderer ?: run { toast("Open a PDF first"); return }
        if(index !in 0 until r.pageCount) { toast("No more pages"); return }
        try {
            val p=r.openPage(index)
            val bmp=Bitmap.createBitmap(p.width*2,p.height*2,Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            p.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); p.close()
            preview.setImageBitmap(bmp); pageIndex=index; drawing.clear()
            status.text="Page ${index+1} / ${r.pageCount}  •  ${mode}"
        } catch(e:Exception){ status.text="Render error: ${e.localizedMessage}" }
    }
    private fun addText() {
        if(currentUri==null){toast("Open a PDF first");return}
        val input=EditText(this).apply { hint="Enter text to add" }
        android.app.AlertDialog.Builder(this).setTitle("Add text to page")
            .setView(input).setPositiveButton("Add"){_,_->
                val s=input.text.toString()
                if(s.isNotBlank()) drawing.addLabel(s)
            }.setNegativeButton("Cancel",null).show()
    }

    private fun saveAs() {
        val uri=currentUri ?: run { toast("Open a PDF first"); return }
        val name="AK_Edited_${System.currentTimeMillis()}.pdf"
        val values=ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME,name); put(MediaStore.Downloads.MIME_TYPE,"application/pdf") }
        val outUri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)
        if(outUri==null){toast("Could not create output file");return}
        try {
            val temp=File(cacheDir,"source.pdf")
            contentResolver.openInputStream(uri).use { input -> FileOutputStream(temp).use { input!!.copyTo(it) } }
            val doc=PDDocument.load(temp)
            val page=doc.getPage(pageIndex)
            val stream=PDPageContentStream(doc,page,PDPageContentStream.AppendMode.APPEND,true,true)
            val pageW=page.mediaBox.width; val pageH=page.mediaBox.height
            val v=drawing.exportSnapshot()
            if(v!=null) {
                val img=LosslessFactory.createFromImage(doc,v)
                stream.drawImage(img,0f,0f,pageW,pageH)
            }
            drawing.labels.forEach { label ->
                stream.beginText(); stream.setFont(PDType1Font.HELVETICA,14f)
                stream.newLineAtOffset(label.x*pageW,label.y*pageH); stream.showText(label.text.take(200)); stream.endText()
            }
            stream.close(); doc.save(contentResolver.openOutputStream(outUri)!!); doc.close()
            toast("Saved to Downloads as $name")
        } catch(e:Exception){ toast("Save failed: ${e.localizedMessage}") }
    }

    private fun createPdfFromImage(bitmap:Bitmap) {
        try {
            val doc=PDDocument(); val page=PDPage(); doc.addPage(page)
            val img=LosslessFactory.createFromImage(doc,bitmap)
            val stream=PDPageContentStream(doc,page)
            val scale=minOf(500f/bitmap.width,700f/bitmap.height)
            stream.drawImage(img,40f,80f,bitmap.width*scale,bitmap.height*scale); stream.close()
            val file=File(cacheDir,"image_converted.pdf"); doc.save(file); doc.close()
            val out=File(getExternalFilesDir(null),"Image_to_PDF.pdf"); file.copyTo(out,true)
            toast("Created PDF: ${out.name}")
        } catch(e:Exception){toast("Conversion failed: ${e.localizedMessage}")}
    }

    private fun merge(uris:List<Uri>) {
        try {
            val merged=PDDocument()
            uris.forEach { uri ->
                val tmp=File(cacheDir,"merge_${System.nanoTime()}.pdf")
                contentResolver.openInputStream(uri).use { input -> FileOutputStream(tmp).use { input!!.copyTo(it) } }
                PDDocument.load(tmp).use { src -> for(p in src.pages) merged.addPage(p) }
                tmp.delete()
            }
            val out=File(getExternalFilesDir(null),"AK_Merged.pdf"); merged.save(out); merged.close()
            toast("Merged file saved: ${out.name}")
        } catch(e:Exception){toast("Merge failed: ${e.localizedMessage}")}
    }
    private fun pageTools() {
        val options=arrayOf("Remove last page (create a copy)", "Split current page (not available yet)")
        android.app.AlertDialog.Builder(this).setTitle("Page tools").setItems(options){_,which->
            if(which==0) removeLastPage() else toast("Split-page export is planned for a later build")
        }.show()
    }
    private fun removeLastPage() {
        val uri=currentUri ?: run{toast("Open a PDF first");return}
        try {
            val tmp=File(cacheDir,"remove.pdf")
            contentResolver.openInputStream(uri).use { input -> FileOutputStream(tmp).use{input!!.copyTo(it)} }
            val doc=PDDocument.load(tmp)
            if(doc.numberOfPages>1) { doc.removePage(doc.numberOfPages-1); val out=File(getExternalFilesDir(null),"AK_Page_Removed.pdf"); doc.save(out); toast("Saved ${out.name}") }
            else toast("Cannot remove the only page")
            doc.close()
        }catch(e:Exception){toast("Page operation failed: ${e.localizedMessage}")}
    }
    private fun closePdf() {
        try{renderer?.close()}catch(_:Exception){}
        try{descriptor?.close()}catch(_:Exception){}
        renderer=null;descriptor=null
    }
    override fun onDestroy(){closePdf();super.onDestroy()}

    private fun AlertDialogBuilder(message:String)=android.app.AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK",null)

    class InkView(context:android.content.Context):View(context) {
        enum class Tool { PEN,HIGHLIGHT }
        data class Label(val text:String,val x:Float,val y:Float)
        var tool=Tool.PEN
        val labels= mutableListOf<Label>()
        private val paths= mutableListOf<Pair<Path,Paint>>()
        private var path=Path()
        private var paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.RED; style=Paint.Style.STROKE; strokeWidth=5f; strokeCap=Paint.Cap.ROUND }
        init { setLayerType(View.LAYER_TYPE_SOFTWARE,null) }
        override fun onDraw(canvas:Canvas) {
            super.onDraw(canvas)
            paths.forEach{canvas.drawPath(it.first,it.second)}
            canvas.drawPath(path,paint)
            labels.forEach { l ->
                val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLUE;textSize=38f}
                canvas.drawText(l.text,l.x*width,l.y*height,p)
            }
        }
        override fun onTouchEvent(event:MotionEvent):Boolean {
            when(event.action) {
                MotionEvent.ACTION_DOWN -> { path=Path();path.moveTo(event.x,event.y); return true }
                MotionEvent.ACTION_MOVE -> { path.lineTo(event.x,event.y);invalidate();return true }
                MotionEvent.ACTION_UP -> {
                    val p=Paint(paint)
                    if(tool==Tool.HIGHLIGHT){p.color=Color.YELLOW;p.alpha=100;p.strokeWidth=22f}
                    paths.add(Pair(Path(path),p));path.reset();invalidate();return true
                }
            }; return true
        }
        fun clear(){paths.clear();labels.clear();path.reset();invalidate()}
        fun addLabel(s:String){labels.add(Label(s,0.1f,0.2f+labels.size*0.08f));invalidate()}
        fun exportSnapshot():Bitmap? {
            if(width<=0||height<=0||paths.isEmpty())return null
            val b=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888)
            val c=Canvas(b); paths.forEach{c.drawPath(it.first,it.second)}; return b
        }
    }
}
