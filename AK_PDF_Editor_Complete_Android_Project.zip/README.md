# AK PDF Editor Complete — Android Studio project

## Implemented in this project
- Open and view PDFs; previous/next page navigation
- Freehand drawing and a highlight-style marker overlay
- Add simple text labels to the current page
- Save current-page annotations into a new PDF in Downloads
- Convert one image to a PDF
- Merge multiple PDFs
- Remove the last page and save a copy

## Not implemented yet
- Editing/replacing existing PDF text (this requires text extraction/layout-aware editing)
- Reliable split/export of arbitrary page ranges
- PDF-to-Word conversion with preserved formatting
- Password encryption/decryption
- Full annotation placement controls, undo/redo, multi-page annotation persistence

## Build the APK
Open this folder in Android Studio, allow Gradle sync and run on a device.
For an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

This is a source project, not a prebuilt APK. Review/test on a device before relying on output. Requires internet during Gradle sync to download PDFBox Android.
